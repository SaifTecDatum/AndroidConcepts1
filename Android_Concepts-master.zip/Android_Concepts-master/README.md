# Android_Concepts Original, Linked with IDE.
