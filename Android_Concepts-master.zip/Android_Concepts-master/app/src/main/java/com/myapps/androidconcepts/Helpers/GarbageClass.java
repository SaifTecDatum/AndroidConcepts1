package com.myapps.androidconcepts.Helpers;

public class GarbageClass  {

    /*Call<List<Pagination_Model>> call = MainApplication.getPaginationRestClient().getMyApi().getPaginationModel(page, limit);

        call.enqueue(new Callback<List<Pagination_Model>>() {       //triedToGetUsingArrayList&ModelButNotGettingInThisWay.
            @Override
            public void onResponse(Call<List<Pagination_Model>> call, Response<List<Pagination_Model>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    progressBar.setVisibility(View.GONE);

                    for (int i = 0; i < response.body().size(); i++) {

                        Pagination_Model model = new Pagination_Model();
                        model.setId(response.body().get(i).getId());
                        model.setAuthor(response.body().get(i).getAuthor());
                        model.setDownload_url(response.body().get(i).getDownload_url());

                        modelList.add(model);

                        adapter = new PaginationAdapter(PaginationRetroRcyclrActivity.this, modelList);
                        recyclerView.setAdapter(adapter);
                    }
                } else {
                    Toast.makeText(PaginationRetroRcyclrActivity.this, "Something Went Wrong..!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Pagination_Model>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(PaginationRetroRcyclrActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });*/

}

/*
public class GarbageClass extends AppCompatActivity implements View.OnClickListener, SurfaceHolder.Callback {
    MediaRecorder recorder;
    SurfaceHolder holder;
    boolean recording = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        recorder = new MediaRecorder();
        initRecorder();
        setContentView(R.layout.video_record_activity);

        SurfaceView cameraView = (SurfaceView) findViewById(R.id.CameraView);
        holder = cameraView.getHolder();
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        cameraView.setClickable(true);
        cameraView.setOnClickListener(this);
    }

    private void initRecorder() {
        recorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
        recorder.setVideoSource(MediaRecorder.VideoSource.DEFAULT);

        CamcorderProfile cpHigh = CamcorderProfile
                .get(CamcorderProfile.QUALITY_HIGH);
        recorder.setProfile(cpHigh);
        recorder.setOutputFile("/sdcard/videocapture_example.mp4");
        recorder.setMaxDuration(50000); // 50 seconds
        recorder.setMaxFileSize(5000000); // Approximately 5 megabytes
    }

    private void prepareRecorder() {
        recorder.setPreviewDisplay(holder.getSurface());

        try {
            recorder.prepare();
        } catch (IllegalStateException e) {
            e.printStackTrace();
            finish();
        } catch (IOException e) {
            e.printStackTrace();
            finish();
        }
    }

    public void onClick(View v) {
        if (recording) {
            recorder.stop();
            recording = false;

            // Let's initRecorder so we can record again
            initRecorder();
            prepareRecorder();
        } else {
            recording = true;
            recorder.start();
        }
    }

    public void surfaceCreated(SurfaceHolder holder) {
        prepareRecorder();
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        if (recording) {
            recorder.stop();
            recording = false;
        }
        recorder.release();
        finish();
    }
}*/
