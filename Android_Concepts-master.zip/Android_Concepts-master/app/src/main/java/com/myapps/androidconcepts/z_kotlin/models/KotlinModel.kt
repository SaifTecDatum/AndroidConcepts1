package com.myapps.androidconcepts.z_kotlin.models

data class KotlinModel(val userId: Int = 0,
                       val id: Int = 0,
                       val title: String = "",
                       val body: String = "")
