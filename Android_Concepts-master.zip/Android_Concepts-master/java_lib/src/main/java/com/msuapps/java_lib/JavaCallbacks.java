package com.msuapps.java_lib;

public interface JavaCallbacks {
    void firstMethod();

    //Interface Process..
    void secondMethod();
}
