package com.myapps.androidconcepts.Helpers;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.myapps.androidconcepts.Interfaces.UserDao;
import com.myapps.androidconcepts.Models.Users;

@Database(entities = {Users.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UserDao userDao();
}