package com.myapps.androidconcepts.Helpers;

import android.app.Application;

public class MainApplication extends Application {
    private static RestClient restClient;
    private static PostRestClient postRestClient;
    private static RecylrRestClient recylrRestClient;
    private static ECommerceRestClient eCommerceRestClient;
    private static AirlinesRestClient airlinesRestClient;
    private static PaginationRestClient paginationRestClient;

    @Override
    public void onCreate() {
        super.onCreate();

        restClient = new RestClient();
        postRestClient = new PostRestClient();
        recylrRestClient = new RecylrRestClient();
        eCommerceRestClient = new ECommerceRestClient();
        airlinesRestClient = new AirlinesRestClient();
        paginationRestClient = new PaginationRestClient();
    }

    public static PostRestClient getPostRestClient() {

        return postRestClient;
    }

    public static RestClient getRestClient() {

        return restClient;
    }

    public static RecylrRestClient getRecylrRestClient() {

        return recylrRestClient;
    }

    public static ECommerceRestClient geteCommerceRestClient() {

        return eCommerceRestClient;
    }

    public static AirlinesRestClient getAirlinesRestClient() {

        return airlinesRestClient;
    }

    public static PaginationRestClient getPaginationRestClient() {

        return paginationRestClient;
    }
}