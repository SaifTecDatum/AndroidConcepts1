package com.myapps.androidconcepts.y_MVVM_DesignPattern;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProviders;

import com.myapps.androidconcepts.R;
import com.myapps.androidconcepts.databinding.ActivityMvvmBinding;

public class MVVM_Activity extends AppCompatActivity {
    private ViewModel viewModel;
    private ActivityMvvmBinding mvvmBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mvvmBinding = DataBindingUtil.setContentView(MVVM_Activity.this, R.layout.activity_mvvm);

        viewModel = ViewModelProviders.of(MVVM_Activity.this).get(ViewModel.class);          //lineToRemember.
        mvvmBinding.setProductModel(viewModel.getProductModel());
    }
}
