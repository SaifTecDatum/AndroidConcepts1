package com.myapps.androidconcepts.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.myapps.androidconcepts.R;

public class SharedPrefrncActivity extends AppCompatActivity {
    private FloatingActionButton floatingActionButton, fab_preferenceDelete;
    private BottomSheetDialog bottomSheetDialog;
    private EditText et_Name, et_Skill;
    private AppCompatButton btn_Submit;
    private SharedPreferences sharedPreferences;
    private TextView tv_CricketerName, tv_CricketerSkill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_prefrnc);

        sharedPreferences = getSharedPreferences("AndroidConcepts", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        tv_CricketerName = findViewById(R.id.tv_CricketerName);
        tv_CricketerSkill = findViewById(R.id.tv_CricketerSkill);
        floatingActionButton = findViewById(R.id.fab_preference);
        fab_preferenceDelete = findViewById(R.id.fab_preferenceDelete);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog = new BottomSheetDialog(SharedPrefrncActivity.this, R.style.BottomSheetStyle);
                bottomSheetDialog.setContentView(R.layout.btmsht_sharedpref);
                bottomSheetDialog.setCanceledOnTouchOutside(false);

                et_Name = bottomSheetDialog.findViewById(R.id.et_Name);
                et_Skill = bottomSheetDialog.findViewById(R.id.et_Skill);
                btn_Submit = bottomSheetDialog.findViewById(R.id.btn_Submit);

                btn_Submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (TextUtils.isEmpty(et_Name.getText().toString().trim())) {
                            et_Name.setError("Cricketer Name Required..!");
                        } else if (TextUtils.isEmpty(et_Skill.getText().toString().trim())) {
                            et_Skill.setError("Cricketer Skill Required..!");
                        } else {
                            editor.putString("name", et_Name.getText().toString().trim());
                            editor.putString("skill", et_Skill.getText().toString().trim());
                            editor.apply();
                            startActivity(new Intent(SharedPrefrncActivity.this, SharedPrefrncActivity.class));
                            finish();
                            bottomSheetDialog.dismiss();
                        }
                    }
                });

                bottomSheetDialog.show();
            }
        });

        fab_preferenceDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String retrieveName = sharedPreferences.getString("name", "");

                if (retrieveName != null && retrieveName.length() > 0) {
                    editor.clear();
                    editor.apply();

                    String retrieveName1 = sharedPreferences.getString("name", "");
                    String retrieveSkill1 = sharedPreferences.getString("skill", "");

                    tv_CricketerName.setText("Cricketer Name: " + retrieveName1);
                    tv_CricketerSkill.setText("Cricketer Skill: " + retrieveSkill1);
                }
            }
        });

        String retrieveName = sharedPreferences.getString("name", "");
        String retrieveSkill = sharedPreferences.getString("skill", "");

        if (retrieveName != null && retrieveSkill.length() > 0) {
            tv_CricketerName.setText("Cricketer Name: " + retrieveName);
            tv_CricketerSkill.setText("Cricketer Skill: " + retrieveSkill);
            Toast.makeText(SharedPrefrncActivity.this, retrieveName + " is your new Player.", Toast.LENGTH_SHORT).show();
        }
    }
}