package com.myapps.androidconcepts.Activities.Retrofit_Volley;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.widget.NestedScrollView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputLayout;
import com.myapps.androidconcepts.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class JsonVolleyActivity extends AppCompatActivity {
    private TextView tv_jsonVolleyGETData, tv_jsonVolleyPOSTData;
    private AppCompatButton btn_jsonVolleyGETData, btn_Submit;
    private RequestQueue requestQueue;
    private TextInputLayout TIL_1, TIL_2, TIL_3;
    private EditText et_Username, et_email, et_retrofit_Password;
    private NestedScrollView nestedScrollView;

    private void InitializeFields() {
        tv_jsonVolleyGETData = findViewById(R.id.tv_jsonVolleyGETData);
        tv_jsonVolleyGETData.setText("");
        tv_jsonVolleyPOSTData = findViewById(R.id.tv_jsonVolleyPOSTData);
        tv_jsonVolleyPOSTData.setText("");
        btn_jsonVolleyGETData = findViewById(R.id.btn_jsonVolleyGETData);
        btn_Submit = findViewById(R.id.btn_Submit);
        TIL_1 = findViewById(R.id.TIL_1);
        TIL_2 = findViewById(R.id.TIL_2);
        TIL_3 = findViewById(R.id.TIL_3);
        et_Username = findViewById(R.id.et_Username);
        et_email = findViewById(R.id.et_email);
        et_retrofit_Password = findViewById(R.id.et_retrofit_Password);
        nestedScrollView = findViewById(R.id.nestedScrollView);

        tv_jsonVolleyGETData.setVisibility(View.GONE);
        tv_jsonVolleyPOSTData.setVisibility(View.VISIBLE);
        TIL_1.setVisibility(View.VISIBLE);
        TIL_2.setVisibility(View.VISIBLE);
        TIL_3.setVisibility(View.VISIBLE);
        btn_Submit.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json_volley);

        InitializeFields();

        requestQueue = Volley.newRequestQueue(JsonVolleyActivity.this);

        btn_jsonVolleyGETData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tv_jsonVolleyGETData.getVisibility() == View.GONE) {
                    tv_jsonVolleyGETData.setVisibility(View.VISIBLE);
                    tv_jsonVolleyPOSTData.setVisibility(View.GONE);
                    TIL_1.setVisibility(View.GONE);
                    TIL_2.setVisibility(View.GONE);
                    TIL_3.setVisibility(View.GONE);
                    btn_Submit.setVisibility(View.GONE);
                } else {
                    tv_jsonVolleyGETData.setVisibility(View.GONE);
                    tv_jsonVolleyPOSTData.setVisibility(View.VISIBLE);
                    TIL_1.setVisibility(View.VISIBLE);
                    TIL_2.setVisibility(View.VISIBLE);
                    TIL_3.setVisibility(View.VISIBLE);
                    btn_Submit.setVisibility(View.VISIBLE);
                }

                jsonParsingGET_viaVolley();
            }
        });

        btn_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jsonParsingPOST_viaVolley();
            }
        });
    }

    private void jsonParsingGET_viaVolley() {
        String url = "https://jsonplaceholder.typicode.com/comments";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        if (response != null) {

                            for (int i = 0; i < response.length(); i++) {

                                try {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    int id = jsonObject.getInt("id");
                                    String name = jsonObject.getString("name");
                                    String email = jsonObject.getString("email");
                                    String body = jsonObject.getString("body");

                                    tv_jsonVolleyGETData.append(
                                            "ID: " + id + "\n" +
                                                    "Name: " + name + "\n" +
                                                    "Email: " + email + "\n" +
                                                    "Description: " + body + "\n\n");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        } else {
                            Toast.makeText(JsonVolleyActivity.this, "Response Error..!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(JsonVolleyActivity.this, error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(jsonArrayRequest);
    }

    private void jsonParsingPOST_viaVolley() {      //OutputErrorInPostRequest.
        RequestQueue requestQueue1 = Volley.newRequestQueue(JsonVolleyActivity.this);

        String postUrl = "http://api.larntech.net/users/";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, postUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        tv_jsonVolleyPOSTData.append("Post Response: " + response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(JsonVolleyActivity.this, "Something went Wrong.. " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> postMap = new HashMap<>();
                postMap.put("username", et_Username.getText().toString().trim());
                postMap.put("email", et_email.getText().toString().trim());
                postMap.put("password", et_retrofit_Password.getText().toString().trim());

                return postMap;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                Map<String, String> postMap = new HashMap<>();
                postMap.put("Content-Type", "application/json");

                return postMap;
            }
        };

        requestQueue1.add(stringRequest);
    }

}
