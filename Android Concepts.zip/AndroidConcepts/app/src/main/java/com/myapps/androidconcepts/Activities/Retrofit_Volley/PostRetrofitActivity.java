package com.myapps.androidconcepts.Activities.Retrofit_Volley;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.myapps.androidconcepts.Helpers.MainApplication;
import com.myapps.androidconcepts.Models.Request_Model;
import com.myapps.androidconcepts.Models.Response_Model;
import com.myapps.androidconcepts.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PostRetrofitActivity extends AppCompatActivity {
    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private Toolbar post_Toolbar;
    private SwipeRefreshLayout swipeRefreshLay;
    private TextView tv_username, tv_id, tv_email, tv_dateJoined, tv_fetchData;
    private FloatingActionButton fab_addUser;
    private EditText et_Username, et_email, et_retrofit_Password;
    private AppCompatButton btn_Submit;
    private ProgressDialog progressDialog;
    private BottomSheetDialog bottomSheetDialog;

    private void initializeFields() {
        post_Toolbar = findViewById(R.id.post_Toolbar);
        setSupportActionBar(post_Toolbar);
        swipeRefreshLay = findViewById(R.id.swipeRefreshLay);
        tv_username = findViewById(R.id.tv_username);
        tv_username.setText("");
        tv_id = findViewById(R.id.tv_id);
        tv_id.setText("");
        tv_email = findViewById(R.id.tv_email);
        tv_email.setText("");
        tv_dateJoined = findViewById(R.id.tv_dateJoined);
        tv_dateJoined.setText("");
        tv_fetchData = findViewById(R.id.tv_fetchData);
        tv_fetchData.setText("");
        fab_addUser = findViewById(R.id.fab_addUser);
        progressDialog = new ProgressDialog(PostRetrofitActivity.this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_retrofit);

        initializeFields();

        ProgressDialog();

        Single<List<Response_Model>> single = MainApplication.getPostRestClient().getMyApi().getAllPostData();
        single.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<List<Response_Model>>() {
                    @Override
                    public void onSubscribe(@NotNull Disposable d) {
                        compositeDisposable.add(d);
                    }

                    @Override
                    public void onSuccess(@NotNull List<Response_Model> response_models) {
                        if (response_models != null) {

                            progressDialog.dismiss();

                            for (int i = 0; i < response_models.size(); i++) {
                                tv_fetchData.append("S.no: " + response_models.get(i).getId() + "\nUsername: "
                                        + response_models.get(i).getUsername() + "\nEmail: " + response_models.get(i).getEmail()
                                        + "\nDate Joined: " + response_models.get(i).getDate_joined() + "\n\n");
                            }
                        } else {
                            progressDialog.dismiss();
                            Toast.makeText(PostRetrofitActivity.this, "Something Went Wrong..", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onError(@NotNull Throwable e) {
                        progressDialog.dismiss();
                        Toast.makeText(PostRetrofitActivity.this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        fab_addUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog = new BottomSheetDialog(PostRetrofitActivity.this, R.style.BottomSheetStyle);
                bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_retrofit);
                bottomSheetDialog.setCanceledOnTouchOutside(false);

                et_Username = bottomSheetDialog.findViewById(R.id.et_Username);
                et_email = bottomSheetDialog.findViewById(R.id.et_email);
                et_retrofit_Password = bottomSheetDialog.findViewById(R.id.et_retrofit_Password);
                btn_Submit = bottomSheetDialog.findViewById(R.id.btn_Submit);

                btn_Submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (TextUtils.isEmpty(et_Username.getText().toString().trim())) {
                            Toast.makeText(PostRetrofitActivity.this, "Username should not be Empty..",
                                    Toast.LENGTH_SHORT).show();
                        } else if (TextUtils.isEmpty(et_email.getText().toString().trim())) {
                            Toast.makeText(PostRetrofitActivity.this, "Email Id should not be Empty..",
                                    Toast.LENGTH_SHORT).show();
                        } else if (TextUtils.isEmpty(et_retrofit_Password.getText().toString().trim())) {
                            Toast.makeText(PostRetrofitActivity.this, "Password should not be Empty..",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Request_Model request_model = new Request_Model(et_Username.getText().toString().trim(),
                                    et_email.getText().toString().trim(), et_retrofit_Password.getText().toString().trim());

                            Call<Response_Model> call = MainApplication.getPostRestClient().getMyApi().getPostModel(request_model);

                            call.enqueue(new Callback<Response_Model>() {
                                @Override
                                public void onResponse(Call<Response_Model> call, Response<Response_Model> response) {
                                    if (response.isSuccessful()) {
                                        Response_Model response_model = response.body();

                                        tv_id.setText(response_model.getId() + "");
                                        tv_username.setText(response_model.getUsername());
                                        tv_email.setText(response_model.getEmail());
                                        tv_dateJoined.setText(response_model.getDate_joined());
                                    } else {
                                        Toast.makeText(PostRetrofitActivity.this, "Something went wrong..", Toast.LENGTH_SHORT).show();
                                    }
                                    bottomSheetDialog.dismiss();
                                }

                                @Override
                                public void onFailure(Call<Response_Model> call, Throwable t) {
                                    Toast.makeText(PostRetrofitActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                    bottomSheetDialog.dismiss();
                                }
                            });
                        }
                    }
                });

                bottomSheetDialog.show();
            }
        });

        /*
        //Fetching/Retrieving Only certain Data from Server wch i have entered by the help of Id's.
        listOfIds.add(919);
        listOfIds.add(921);
        listOfIds.add(922);
        listOfIds.add(923);
        listOfIds.add(926);
        listOfIds.add(930);
        listOfIds.add(931);
        listOfIds.add(933);
        listOfIds.add(936);
        listOfIds.add(937);
        listOfIds.add(938);
        listOfIds.add(939);
        listOfIds.add(947);

        for (int i=0; i<listOfIds.size(); i++) {

            Call<Response_Model> postCall = MainApplication.getPostRestClient().getMyApi().getNetworkDetails(listOfIds.get(i));

            postCall.enqueue(new Callback<Response_Model>() {
                @Override
                public void onResponse(Call<Response_Model> call, Response<Response_Model> response) {
                    if (response.isSuccessful()) {
                        Response_Model responseModel = response.body();

                        tv_fetchData.append("S.no: " + responseModel.getId() + "\nUsername: " +
                                responseModel.getUsername() + "\nEmail: " + responseModel.getEmail() +
                                "\nDate_Joined: " + responseModel.getDate_joined() + "\n\n");
                    }
                    else {
                        Toast.makeText(PostRetrofitActivity.this, "FetchingDataError", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Response_Model> call, Throwable t) {
                    Toast.makeText(PostRetrofitActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            });

        }*/

        swipeRefreshLay.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLay.setRefreshing(false);
                startActivity(new Intent(PostRetrofitActivity.this, PostRetrofitActivity.class));
                finish();
            }
        });
    }

    public void ProgressDialog() {
        progressDialog.setTitle("Please Wait..");
        progressDialog.setMessage("fetching data from server..");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

}