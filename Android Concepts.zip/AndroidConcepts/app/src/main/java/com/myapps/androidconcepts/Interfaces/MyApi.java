package com.myapps.androidconcepts.Interfaces;

import com.myapps.androidconcepts.Models.AllTypesRetrofit_Model;
import com.myapps.androidconcepts.Models.RecyclerRetrofit_Model;
import com.myapps.androidconcepts.Models.Request_Model;
import com.myapps.androidconcepts.Models.Response_Model;
import com.myapps.androidconcepts.Models.RetrofitAirlines_Model;
import com.myapps.androidconcepts.Models.RetrofitEcommerce_Model;
import com.myapps.androidconcepts.Models.Retrofit_Model;

import java.util.List;

import io.reactivex.Single;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MyApi {

    @GET("comments/")
    Call<List<Retrofit_Model>> getModel();

    @POST("users/")
    Call<Response_Model> getPostModel(@Body Request_Model request_model);

    /*@GET("users/{id}/")
    Call<Response_Model> getNetworkDetails(@Path("id") int id);*/

    @GET("users/")
    Single<List<Response_Model>> getAllPostData();

    @GET("users")
    Call<List<RecyclerRetrofit_Model>> getRecyclerModel();

    @GET("products")
    Call<List<RetrofitEcommerce_Model>> getEcommerceRetroModel();

    @GET("airlines")
    Call<List<RetrofitAirlines_Model>> getAirlinesData();

    @GET("airlines")
    Call<String> STRING_CALL1(@Query("page") int page, @Query("limit") int limit);

    @GET("v2/list")
    Call<String> STRING_CALL(@Query("page") int page, @Query("limit") int limit);

    /*@GET("v2/list")   //triedToGetUsingArrayList&ModelButNotGettingInThisWay.
    Call<List<Pagination_Model>> getPaginationModel(@Query("page") int page, @Query("limit") int limit);*/

    //____________________________________________________________________________________________________________________________

    @GET("posts")
    Call<List<AllTypesRetrofit_Model>> GET_data();

    @POST("posts")
    Call<AllTypesRetrofit_Model> POST_data(@Body AllTypesRetrofit_Model setPOST_model);

    @PUT("posts/{id}")
    Call<AllTypesRetrofit_Model> PUT_data(@Path("id") int id, @Body AllTypesRetrofit_Model setPUT_model);

    @PATCH("posts/{id}")
    Call<AllTypesRetrofit_Model> PATCH_data(@Path("id") int id, @Body AllTypesRetrofit_Model setPATCH_model);

    @DELETE("posts/{id}")
    Call<AllTypesRetrofit_Model> DELETE_data(@Path("id") int id);

}