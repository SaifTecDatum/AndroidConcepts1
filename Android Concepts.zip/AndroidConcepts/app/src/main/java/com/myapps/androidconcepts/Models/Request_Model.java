package com.myapps.androidconcepts.Models;

public class Request_Model {
    private final Boolean is_active = true;         //eitherWeCanKeepTrueOrFalse,noPrblms.
    private final String date_joined = "2021-09-29 18:46:31";   //mustGiveTime&DateHere
    private String username;                //mustGiveUsernameToo.
    private String first_name;
    private String last_name;
    private String email;
    private String password;           //mustGivePasswordToo.

    public Request_Model(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
