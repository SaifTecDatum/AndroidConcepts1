package com.myapps.androidconcepts.Interfaces;

import com.google.android.exoplayer2.ui.PlayerView;

public interface VideoCallbacks {

    PlayerView getPlayerView(PlayerView playerView);

}
