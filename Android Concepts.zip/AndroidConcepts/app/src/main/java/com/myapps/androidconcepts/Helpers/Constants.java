package com.myapps.androidconcepts.Helpers;

public class Constants {
    public static final String uId = "UId";
    public static final String users = "Users";
    public static final String device_token = "Device Token";
    public static final String baseUrl = "https://jsonplaceholder.typicode.com/";   //usingForTwoRetrofits.
    public static final String postUrl = "http://api.larntech.net/";
    public static final String eCommerceBaseUrl = "https://fakestoreapi.com/";
    public static final String airlinesBaseUrl = "https://api.instantwebtools.net/v1/";
    public static final String photosBaseUrl = "https://picsum.photos/";
    public static final String profilePic = "ProfilePic";
    public static final String googlePic = "GooglePic";
    public static final String userFullName = "User FullName";
    public static final String userStatus = "User Status";
    public static final String userContact = "User Contact";
    public static final String myVideos = "My Videos";
    public static final String videos = "Videos";
    public static final String googleName = "Google Name";
    public static final String authType = "Auth Type";
    public static final String googleAuth = "Google Holder";
    public static final String phoneAuth = "Phone Auth Holder";
    public static final String nrmlAuth = "Nrml Auth Holder";
    public static final String notifyChannelId = "Channel Id";
    public static final String notifyName = "My Notification";
    public static final String parcelable_Key = "Json Users Data";
    public static final String ACTION_CUSTOM_BRDCSTRCVR = "myCustomBroadcastRcvr_EXAMPLE_ACTION";
    public static final String razorpayKey_Id = "rzp_test_pjKEr5RfPJmDic";

}

