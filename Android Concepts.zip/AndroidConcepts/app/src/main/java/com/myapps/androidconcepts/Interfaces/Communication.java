package com.myapps.androidconcepts.Interfaces;

public interface Communication {

    void sendData();
}
