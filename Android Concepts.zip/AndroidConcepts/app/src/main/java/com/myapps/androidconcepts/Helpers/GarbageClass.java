package com.myapps.androidconcepts.Helpers;

public class GarbageClass {

    /*Call<List<Pagination_Model>> call = MainApplication.getPaginationRestClient().getMyApi().getPaginationModel(page, limit);

        call.enqueue(new Callback<List<Pagination_Model>>() {       //triedToGetUsingArrayList&ModelButNotGettingInThisWay.
            @Override
            public void onResponse(Call<List<Pagination_Model>> call, Response<List<Pagination_Model>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    progressBar.setVisibility(View.GONE);

                    for (int i = 0; i < response.body().size(); i++) {

                        Pagination_Model model = new Pagination_Model();
                        model.setId(response.body().get(i).getId());
                        model.setAuthor(response.body().get(i).getAuthor());
                        model.setDownload_url(response.body().get(i).getDownload_url());

                        modelList.add(model);

                        adapter = new PaginationAdapter(PaginationRetroRcyclrActivity.this, modelList);
                        recyclerView.setAdapter(adapter);
                    }
                } else {
                    Toast.makeText(PaginationRetroRcyclrActivity.this, "Something Went Wrong..!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Pagination_Model>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(PaginationRetroRcyclrActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });*/


}
