package com.myapps.androidconcepts.Interfaces;

public interface MyCallbacks {

    void deleteItems(int id);

    void updateItems(int id, String name, String description, double gdp);
}