package com.myapps.androidconcepts.Models;

public class Response_Model {
    private int id;
    private String username, email, date_joined;

    public Response_Model(int id, String username, String email, String date_joined) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.date_joined = date_joined;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDate_joined() {
        return date_joined;
    }

    public void setDate_joined(String date_joined) {
        this.date_joined = date_joined;
    }
}
