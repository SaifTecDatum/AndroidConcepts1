package com.msuapps.java_lib;

/*public class MyClass {
    public static void main(String[] args) {

        for (int i = 0; i <= 10;  i = i + 2) {     //forLoop
            System.out.println(i);
        }
    }
}*/

/*public class MyClass {
    public static void main(String[] args) {
        String[] cars = {"Jaguar", "BMW", "Volvo", "Ferrari", "Skoda", "I20"};

        for (String i : cars) {                     //forEach Loop
            System.out.println(i);
        }
    }
}*/

/*public class MyClass {
    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {

            if (i == 4) {               //forLoop Break Statement.
                break;
            }

            System.out.println(i);
        }
    }
}*/

/*public class MyClass {
    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {

            if (i == 4) {
                continue;                   //forLoop Continue Statement. result: except 4 remaining digits output.
            }
            System.out.println(i);
        }

        System.out.println("Welcome to Android.."); //here"ln"meansIt'llProvideNextLineEmptyToLookGoodViewForNextOutput.
        System.out.print(1+2);
        System.out.print(false);
    }
}*/

/*public class MyClass {
    public static void main(String[] args) {
        String[] cars = {"Ferrari", "Lamborghini", "Mahendra XUV500", "Skoda", "Jaguar", "Volvo"};

        cars[0] = "Opel";
        System.out.println(cars[0]);            //taking position of value-index.

        int i = cars[1].length();               //length.
        System.out.println(cars[1] + " letters length is: " + i);
    }
}*/

/*public class MyClass {
    static void myMethod(String fName, double age) {
        System.out.println(fName + "Uddin" + " is : " + age);   //methodWithParametersPassedInIt.
    }

    public static void main(String[] args) {

         myMethod("late(NanaSaab) - Nizam", 86);
        myMethod("Saif", 29.1);                       //methodWithArgumentsPassedInIt.
        myMethod("Salah", 2);
    }
}*/

/*public class MyClass {

    static int myMethod(int x, int y) {

        return x + y;                   //returnValues - inWchWeWontGetVoidInMethodsInsteadWeGetPrimitiveDataTypes(int,char..etc)
    }

    public static void main(String[] args) {

        System.out.println(myMethod(14, 14));
    }
}*/

/*public class MyClass {

    static void checkAge(int x) {                   //A Method with If...Else statements.
        if (x < 18) {
            System.out.println("Access denied - You are not old enough! :" + x);
        }
        else {
            System.out.println("Access granted - You are old enough! :" + x);
        }
    }

    public static void main(String[] args) {
        checkAge(20);
        checkAge(14);
    }
}*/

/*public class MyClass {

    static int myMethod(int x, int y) {
        return x + y;
    }
                                                        //Method Overloading, meansSameMethodNameWeCan
    static double myMethod(double x, double y) {      //OverloadIt(reuse)ButMustHaveDifferentParameters.
        return x + y;
    }

    public static void main(String[] args) {
        int z1 = myMethod(5, 10);
        System.out.println(z1);

        double z2 = myMethod(10.99, 5.50);
        System.out.println(z2);
    }
}*/

/*public class MyClass {
    int x = 5;                                   //objects&Classes

    public static void main(String[] args) {
        MyClass myObj = new MyClass();

        System.out.println(myObj.x);
    }
}*/

/*public class MyClass {
    static void myStaticMethod() {
        System.out.println("Static methods can be called without creating objects");
    }                                                                   //Java Modifiers.
                                                                //differenceBetweenStatic&PublicMethods
    public void myPublicMethod() {
        System.out.println("Public methods must be called by creating objects");
    }

    public static void main(String[] args) {
        myStaticMethod();

        MyClass myObj = new MyClass();
        myObj.myPublicMethod();
    }
}*/

/*public class MyClass {              //ConstructorWithParameters
    int modelYear;
    String modelName;

    public MyClass(int year, String name) {
        modelYear = year;
        modelName = name;
    }

    public static void main(String[] args) {
        MyClass myCar = new MyClass(1992, "Jaguar");
        System.out.println(myCar.modelName + "  " + myCar.modelYear);
    }
}*/

/*class Person {
    private String name;            //private = restricted access , EncapsulationProcess - ModelClass

    public String getName() {                    //Getters&Setters
        return name;
    }

    public void setName(String newName) {
        this.name = newName;
    }
}

public class MyClass {

    public static void main(String[] args) {
        Person myObj = new Person();
        myObj.setName("Saifuddin's Model Class which have Getter&Setters and its Officially Known as ENCAPSULATION.");               // Set the value of the name variable to "John"
        System.out.println(myObj.getName());
    }
}*/

/*import java.util.Scanner;                   //java Packages & API - UserInput
                                            //ScannerIsJustAExampleToShowHowToImportTheThingsHere.
public class MyClass {                          //we'reNotGettingOutputByThis.

    public static void main(String[] args) {

        Scanner myScannerObj = new Scanner(System.in);

        System.out.println("Enter username");

        String userName = myScannerObj.nextLine();

        System.out.println("UserName is: " + userName);

    }
}*/

/*public class MyClass extends YourClass {           //hereWeAreUsingTwoClasses.usingOneClassAttributes,MethodsInAnotherClass
                                                    //wchIsKnownAsSubClass&SuperClass - " Inheritance Process ".
    String model = "I20";

    public static void main(String[] args) {
                                                        //subClass.
        MyClass myClass = new MyClass();

        myClass.vehicle();

        System.out.println(myClass.brand + "  " + myClass.model);
    }
}

class YourClass {          //superClass.
    String brand = "Hyundai";  //attribute or variable.

    public void vehicle() {
        System.out.println("Caar  Caar..!");        //method
    }
}*/

/*class SuperClass {
      String job = "software Engg.";

      public void manager() {
          System.out.println("jobs mela Opened..!");
      }

}
                                                        //another Ex. for Inheritance as same above.
public class MyClass extends SuperClass{
      String occupation = "Android Developer";

      public static void main(String[] args) {

          MyClass myClass = new MyClass();

          myClass.manager();

          System.out.println(myClass.job + "  " + myClass.occupation);
      }
}*/

/*public class MyClass {
                                                    //Polymorphism means "many forms", and it occurs when we have many
    public static void main(String[] args) {        //classes that are related to each other by inheritance. source:w3Schools.com

        Animal animal = new Animal();
        Animal lion = new Lion();
        Animal cat = new Cat();

        animal.myAnimal();
        lion.myAnimal();
        cat.myAnimal();
    }
}                                       //Polymorphism. its a process whr multiClasses come together with related methods
                                             //by extending & gives output in Main Class.   source:myOwn.
class Animal {
    public void myAnimal() {
        System.out.println("Animals makes different Sounds");
    }
}

class Lion extends Animal {

    public void myAnimal() {
        System.out.println("Lion says something like Roar.. roar..!");
    }
}

class Cat extends Animal {
    public void myAnimal() {
        System.out.println("Cats says something like Meow.. meow..!");
    }
}*/

/*public class MyClass {                              //InnerClasses - regular.

    public static void main(String[] args) {

        OuterClass myOuterClass = new OuterClass();

        OuterClass.InnerClass myInnerClass = myOuterClass.new InnerClass();

        System.out.println(myOuterClass.x + myInnerClass.y);
    }
}

class OuterClass {
    int x = 20;

    class InnerClass {
        int y = 8;

    }
}*/

/*public class MyClass {                              //InnerClasses - private.
                                                        //hereWeCan'tAccessInnerClass&WillGetError,BcozOfPrivate.
    public static void main(String[] args) {

        OuterClass myOuterClass = new OuterClass();

        OuterClass.InnerClass myInnerClass = myOuterClass.new InnerClass();

        System.out.println(myOuterClass.x + myInnerClass.y);
    }
}

class OuterClass {
    int x = 20;

    private class InnerClass {
        int y = 8;

    }
}*/

/*public class MyClass {                              //InnerClasses - static.
                                //differenceIsHereWhileCreatingObjectOfInnerClassWeDon'tTakeOuterClassObjectRef.
    public static void main(String[] args) {

        OuterClass myOuterClass = new OuterClass();

        OuterClass.InnerClass myInnerClass = new OuterClass.InnerClass();

        System.out.println(myOuterClass.x + myInnerClass.y);
    }
}

class OuterClass {
    int x = 20;

    static class InnerClass {
        int y = 8;

    }
}*/

/*public class MyClass {                      //Access Outer Class From Inner Class. (InnerClasses Concept)

    public static void main(String[] args) {

        OuterClass outerClass = new OuterClass();
        OuterClass.InnerClass innerClass = outerClass.new InnerClass();

        System.out.println(innerClass.innerMethod());
    }
}

class OuterClass {
    int x = 28;

    class InnerClass {
        public int innerMethod() {
            return x;
        }
    }
}*/

/*public class MyClass {                            //Interface Process - whereAs Abstraction Process also have the same Concept.
    public static void main(String[] args) {

        SecondClass secondClass = new SecondClass();

        secondClass.firstMethod();
        secondClass.secondMethod();
    }
}

interface Callbacks {
    void firstMethod();
                                            //eitherWeCanUseThisInterfaceOrJavaCallbacksInterfaceFileBothGivesSameResult.
    void secondMethod();             //ifWeUseJavaCallbacksThenThoseMethodsAreGettingActivatedWhileImplementingButNotHere.
}

class SecondClass implements JavaCallbacks{

    @Override
    public void firstMethod() {
        System.out.println("this is a 1st method of Interface process..");
    }

    @Override
    public void secondMethod() {
        System.out.println("this is a 2nd method of Interface process..");
    }
}*/

/*import java.text.SimpleDateFormat;
import java.time.LocalDateTime;                 //importForDate&TimeWchGivesDefaultFormat
import java.time.format.DateTimeFormatter;      //importFormatterWhrWeCanFormatItInGoodView
import java.util.Calendar;
import java.util.Date;

public class MyClass {
    public static void main(String[] args) {
                                                                    //Java Date and Time
        LocalDateTime mydateTimeObj = LocalDateTime.now();
        System.out.println("before Formatting : " + mydateTimeObj);

        DateTimeFormatter dateTimeFormatObj = DateTimeFormatter.ofPattern("dd:MMM:yyyy   hh:mm a");
        String formattedDateTime =  mydateTimeObj.format(dateTimeFormatObj);
        System.out.println("After formatting : " + formattedDateTime);
        //thisOneLearnedfromW3Schools-JavaCourse.


        //thisBelowOneLearnedFromAndroidStudio&AlsoWeUseThisOne.
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        String getTime = timeFormat.format(calendar.getTime());
        SimpleDateFormat dateFormat = new SimpleDateFormat("E,MMM dd yyyy");    //here E show the Day. ex: Mon,Tue,Wed
        String getDate = dateFormat.format(calendar.getTime());

        System.out.println("Time: " + getTime + "\n" + "Date: " + getDate);


        //thisBelowOneLooksEasyCompareToAbove2Processes
        String timeDateStamp = new SimpleDateFormat("hh:mm a   &   E,MMM dd yyyy").format(new Date());
        String timeStamp = new SimpleDateFormat("hh:mm a").format(new Date());
        String dateStamp = new SimpleDateFormat("E,MMM dd yyyy").format(new Date());
        System.out.println("Time: " + timeStamp + " & Date: " + dateStamp);

    }

}*/

/*import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MyClass {

    public static void main(String[] args) {

        LocalDate localDateObj = LocalDate.now();
        LocalTime localTimeObj = LocalTime.now();
        LocalDateTime localDateTimeObj = LocalDateTime.now();

        DateTimeFormatter dateTimeFormatterObj = DateTimeFormatter.ofPattern("hh:mm a  --  E,MMM dd yyyy");

        String format = localDateTimeObj.format(dateTimeFormatterObj);

        System.out.println(localDateObj);
        System.out.println(localTimeObj);
        System.out.println(localDateTimeObj);
        System.out.println(format);
    }
}*/

/*import java.util.ArrayList;
import java.util.Collections;

public class MyClass {                                  //ArrayList
    public static void main(String[] args) {
        ArrayList<String> stringArrayList = new ArrayList<String>();

        stringArrayList.add("elephant");
        stringArrayList.add("cat");
        stringArrayList.add("yank");
        stringArrayList.add("zebra");
        stringArrayList.add("apple");
        stringArrayList.add("frog");
        stringArrayList.add("bat");
        stringArrayList.add("dog");

        stringArrayList.add(0, "animals");

        System.out.println(stringArrayList);        //normalOutput

        System.out.println("\n" + stringArrayList.get(0) + "\n");       //takingCertainOutput

        Collections.sort(stringArrayList);          //SortingTheListItemsInOrder.

        for (int i=0; i<stringArrayList.size(); i++) {       //dngForLoop

            System.out.println(stringArrayList.get(i));
        }

    }
}*/

//hereWeHave"LinkedList"too, but bothAreSameOverAll.
//toAddNewItemsInArrayListWeDo " list.add(0, "car") " WhereAsInLinkedListWeDo " list.addFirst("car") ".

/*import java.util.HashMap;

public class MyClass {                      //HashMap

    public static void main(String[] args) {

        HashMap<String, String> stringHashMap = new HashMap<>();

        stringHashMap.put("Car", "Hyundai-i20");
        stringHashMap.put("Bike", "Pulsar DTSi 150cc");
        stringHashMap.put("BiCycle", "Neon");
        stringHashMap.put("Home", "Duplex");
        stringHashMap.put("HolidayTrip", "Maldives");
        stringHashMap.put("RegionalTrip", "Mecca");

        System.out.println(stringHashMap + "\n");                          //NormalOutput

        System.out.println(stringHashMap.get("Car") + "\n");               //gettingCertainValueByMentioningKey

        System.out.println(stringHashMap.remove("Car") + "\n");        //removingCertainValueByMentioningKey

        System.out.println(stringHashMap.size() + "\n");                    //gettingNo.ofItemsInTheList.

        for (String i : stringHashMap.keySet()) {                   //gettingKeysByFor-EachLoop.
            System.out.println(i);
        }

        System.out.println("");
        for (String i : stringHashMap.values()) {                   //gettingValuesByFor-EachLoop.
            System.out.println(i);
        }

        System.out.println("");
        for (String i : stringHashMap.keySet()) {                   //gettingKeys&ValuesByFor-EachLoop.
            System.out.println("keys: " + i + "    " + "Values: " + stringHashMap.get(i));
        }

    }
}*/

/*import java.util.HashSet;
                                                                //HashSet
public class MyClass {              //SimilarToHashMapButHereWeDon'tHaveKeyValues,onlySingleValuesToAdd.

    public static void main(String[] args) {
        HashSet<Integer> integerHashSet = new HashSet<>();

        integerHashSet.add(1);
        integerHashSet.add(3);
        integerHashSet.add(6);
        integerHashSet.add(8);
        integerHashSet.add(10);
        integerHashSet.add(15);
        integerHashSet.add(17);
        integerHashSet.add(0);
        integerHashSet.add(14);

        System.out.println(integerHashSet.contains(6) + "\n");          //checkingWhetherAnItemExistsIn a HashSetOrNot.
                                                                                //givesTrueOrFalse.
        for (int i = 0; i <= integerHashSet.size(); i++) {
            if (integerHashSet.contains(i)) {
                System.out.println(i + " was found in the Set");
            }
            else {
                System.out.println(i + " was not found in the Set");
            }
        }
    }
}*/

/*import java.util.ArrayList;
import java.util.Iterator;

public class MyClass {                                  //Iterator

    public static void main(String[] args) {

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Electrical Devices");
        arrayList.add("Mobile");
        arrayList.add("Laptop");
        arrayList.add("Television");
        arrayList.add("Trimmer");
        arrayList.add("Power Bank");
        arrayList.add("Alexa Speaker");
        arrayList.add("IronBox");

        Iterator<String> iterator = arrayList.iterator();

        //System.out.println(iterator.next());          //forGettingFirstValue.

        while (iterator.hasNext()) {
            System.out.println(iterator.next());         //forGettingTotalValues.
        }

        ArrayList<Integer> arrayList1 = new ArrayList<>();      //2nd ArrayList
        arrayList1.add(2);
        arrayList1.add(4);
        arrayList1.add(6);
        arrayList1.add(8);
        arrayList1.add(10);
        arrayList1.add(12);
        arrayList1.add(14);
        arrayList1.add(16);
        arrayList1.add(18);
        arrayList1.add(20);
        arrayList1.add(22);

        Iterator<Integer> iterator1 = arrayList1.iterator();

        while (iterator1.hasNext()) {
            int i = iterator1.next();

            if (i < 10) {
                iterator1.remove();                 //Removing Items from a Collection wch r below 10 in the list.
            }
        }

        System.out.println(arrayList1);                 //Remaining items Output..
    }
}*/

/*public class MyClass {              //Wrapper Classes - inWchWeHave1stLetterOfDataTypesInUpperCaseLetter&fullWord.
                                                //justForKnowledge-veryLessUseful.
    public static void main(String[] args) {

        Integer myInt = 100;
        Double myDouble = 99.99;
        Character myChar = 'A';

        System.out.println(myInt.intValue());
        System.out.println(myDouble.doubleValue());
        System.out.println(myChar.charValue());

        String myString = myInt.toString();
        System.out.println(myString.length());

    }
}*/

/*public class MyClass {                      //Exceptions
                                        //inThisChapterWeHaveTryCatchMethodsTooWchIKnowAlready.
     static void myMethod(int age) {
        if (age < 18) {
            throw new ArithmeticException("Access denied - you must be atleast 18 years Old..");
        }
        else {
            System.out.println("Access granted - you are Old enough..");
        }
    }

    public static void main(String[] args) {
        myMethod(36);
        myMethod(15);
    }
}*/

/*import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyClass {                              //RegEx - Regular Expressions.
    public static void main(String[] args) {

        Pattern pattern = Pattern.compile("jobs|for|dev",   Pattern.CASE_INSENSITIVE);  //Pattern Class - Defines a pattern (to be used in a search)

        Matcher matcher = pattern.matcher("looking for android developer Jobs");    //Matcher Class - Used to search for the pattern

        boolean matcherFound = matcher.find();  //find() returns true if the pattern was found in the string and false if not found.

        if (matcherFound) {
            System.out.println("Match has found");
        }
        else {
            System.out.println("<Match has not found..");
        }

    }

}*/

/*public class MyClass{

    //Program For MultiDimensional Array in java

    public static void main(String[] args) {

        int[][] twoDimensionalArray = new int[2][3];
        int[][] twoDArray = new int[2][];
        twoDArray[0] = new int[2];
        twoDArray[1] = new int[2];
        twoDArray[0][0] = 1;
        twoDArray[0][1] = 2;
        twoDArray[1][0] = 4;
        twoDArray[1][1] = 5;

        String[][] str = {{"Hello","Mr"},{"How","You"}};
        String[][] str1 = new String[2][2];

        str1[0][0] = "Hello";
        str1[0][1] = "Mr";
        str1[1][0] = "How";
        str1[1][1] = "You";

        System.out.println("The Result for twoDimensionalArray is:");

        twoDimensionalArray[0][0] = 0;

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 3; j++){
                twoDimensionalArray[i][j] = i + j;
                System.out.print(+twoDimensionalArray[i][j]);
                System.out.print("\t");
            }
            System.out.print("\n");
        }



        System.out.println("The Result for twoDArray is:");

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 2; j++){
                System.out.print(twoDArray[i][j]);
                System.out.print("\t");
            }

            System.out.print("\n");
        }

        System.out.println("The Result for String Array is:");

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 2; j++){
                System.out.print(str[i][j]);
                System.out.print("\t");
            }
            System.out.print("\n");
        }

        System.out.println("The Result for String Array by initializing in different way is:");

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 2; j++){

                System.out.print(str[i][j]);
                System.out.print("\t");

            }
            System.out.print("\n");
        }
    }
}*/

/*public class MyClass {      //Swapping two variables without using a third variable

    public static void main(String[] args) {

        System.out.println("Enter the value of x and y");
        //Define variables
        int x = 23;
        int y = 43;
        System.out.println("before swapping numbers: "+ x +" "+ y);
        //Swapping
        x = x + y;
        System.out.println("x = " + x);

        y = x - y;
        System.out.println("y = " + y);

        x = x - y;
        System.out.println("x = " + x);

        System.out.println("After swapping: "+x +"  " + y);
    }
}*/

/*import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MyClass {
    private static List<String> listOfData = Arrays.asList("Android", "Byte", "Collude", "Debug");
    private static List<String> stringList = new ArrayList<>();

    public static void main(String[] args) {

        System.out.println(listOfData);
        //Collections.reverse(listOfData);    //1st Approach using Collections.reverse
        //System.out.println(listOfData);
                                                            //lastPositionWeHave=3,   lastSizWeHave=4
        for (int i = listOfData.size()-1; i >= 0; i--) {    //hereWeAreTakingListOfDataPositionByCalculatingListOfDataSize.
            System.out.println(i + "");
            //System.out.println(listOfData.get(i));        //2nd Approach.

            stringList.add(listOfData.get(i));
        }

        System.out.println(stringList.toString());
    }
}*/